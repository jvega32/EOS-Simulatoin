#include <RAT/TrackInfo.hh>

namespace RAT {

G4Allocator<TrackInfo> aTrackInfoAllocator;

}  // namespace RAT
