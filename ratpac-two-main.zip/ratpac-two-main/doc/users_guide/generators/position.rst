Position generators
```````````````````
Position generators select points in space for the initial particles.

.. include:: /users_guide/generators/position/point.rst
.. include:: /users_guide/generators/position/fill.rst
.. include:: /users_guide/generators/position/regexfill.rst
.. include:: /users_guide/generators/position/multipoint.rst
.. include:: /users_guide/generators/position/fillshell.rst
.. include:: /users_guide/generators/position/paint.rst
