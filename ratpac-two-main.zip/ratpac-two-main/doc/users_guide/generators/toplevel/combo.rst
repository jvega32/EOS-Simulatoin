combo
'''''
::

    /generator/add combo VERTEX:POSITION:TIME

or

::

    /generator/add combo VERTEX:POSITION

Creates a new combo generator using the vertex, position, and time generators
described below.  If the variant without a TIME parameter is used, it implies
the "poisson" time generator.
