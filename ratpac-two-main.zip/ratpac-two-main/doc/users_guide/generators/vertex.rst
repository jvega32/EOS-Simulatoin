Vertex generators
`````````````````
Vertex generators select the initial particle types, number, momenta, and
polarization.

.. include:: /users_guide/generators/vertex/gun.rst
.. include:: /users_guide/generators/vertex/gun2.rst
.. include:: /users_guide/generators/vertex/es.rst
.. include:: /users_guide/generators/vertex/ibd.rst
.. include:: /users_guide/generators/vertex/reacibd.rst
.. include:: /users_guide/generators/vertex/pbomb.rst
.. include:: /users_guide/generators/vertex/spectrum.rst
