Top-level generators
````````````````````
Top-level generators are understood by the /generator/add command.

.. include:: /users_guide/generators/toplevel/combo.rst
.. include:: /users_guide/generators/toplevel/decaychain.rst
.. include:: /users_guide/generators/toplevel/cfsource.rst
.. include:: /users_guide/generators/toplevel/led.rst
.. include:: /users_guide/generators/toplevel/external.rst
.. include:: /users_guide/generators/toplevel/vertexfile.rst
