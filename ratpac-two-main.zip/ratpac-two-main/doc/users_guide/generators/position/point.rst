point
'''''
::

    /generator/pos/set x y z

Events at a single point.  Coordinates x, y, z are in mm.
