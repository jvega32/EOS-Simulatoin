fill
''''
::

    /generator/pos/set x y z

Events uniformly fill a physical volume containing the point (x, y, z) (mm).
