paint
'''''
::

    /generator/pos/set x y z

Events a distributed uniformly over the surface of the logical volume
containing the point (x, y, z) (mm).
