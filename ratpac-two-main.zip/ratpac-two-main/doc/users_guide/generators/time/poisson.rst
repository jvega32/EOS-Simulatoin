poisson
'''''''
::

    /generator/rate/set evrate

The event rate is a poisson distribtion with mean of evrate (1/seconds).
