uniform
'''''''
::

    /generator/rate/set evrate

Time between events is exactly 1/evrate (seconds).
