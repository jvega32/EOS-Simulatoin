Time generators
```````````````
Time generators control the interval between events for a given generator.

.. include:: /users_guide/generators/time/poisson.rst
.. include:: /users_guide/generators/time/uniform.rst
