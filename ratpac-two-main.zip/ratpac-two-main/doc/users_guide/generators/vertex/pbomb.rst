pbomb
'''''
Generate a photon bomb, i.e. an isotropic distribution of photons, of a given
number and wavelength.

Example::

    /generator/vtx/set 1000 385

Produces events where each contains 1000 photons, each with a wavelength of 385
nanometers.
